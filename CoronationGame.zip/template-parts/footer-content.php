<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-b96d">
  <div class="u-clearfix u-sheet u-sheet-1">
    <p class="u-small-text u-text u-text-variant u-text-1"> ©2021 - Twin Sword Studio - All Rights Reserved</p>
  </div>
</footer>