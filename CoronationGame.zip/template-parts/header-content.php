<header class="u-align-center-sm u-align-center-xs u-clearfix u-custom-color-1 u-header u-sticky u-sticky-9a0b u-header" id="sec-1175">
  <div class="u-clearfix u-sheet u-sheet-1">
    <?php
            ob_start();
            ?><nav class="u-align-left u-menu u-menu-dropdown u-offcanvas u-menu-1">
      <div class="menu-collapse" style="font-size: 0.875rem;">
        <a class="u-button-style u-custom-text-active-color u-custom-text-color u-custom-text-hover-color u-nav-link" href="#">
          <svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 302 302" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-8a8f"></use></svg>
          <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="svg-8a8f" x="0px" y="0px" viewBox="0 0 302 302" style="enable-background:new 0 0 302 302;" xml:space="preserve" class="u-svg-content"><g><rect y="36" width="302" height="30"></rect><rect y="236" width="302" height="30"></rect><rect y="136" width="302" height="30"></rect>
</g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g><g></g></svg>
        </a>
      </div>
      <div class="u-custom-menu u-nav-container">
        {menu}
      </div>
      <div class="u-custom-menu u-nav-container-collapse">
        <div class="u-align-center u-black u-container-style u-inner-container-layout u-opacity u-opacity-95 u-sidenav">
          <div class="u-inner-container-layout u-sidenav-overflow">
            <div class="u-menu-close"></div>
            {responsive_menu}
          </div>
        </div>
        <div class="u-black u-menu-overlay u-opacity u-opacity-70"></div>
      </div>
    </nav><?php
            $megaMenuOptionsPath = get_theme_file_path('/template-parts/menu/mega-menu-primary-navigation-1.json');
            $megaMenu = file_exists($megaMenuOptionsPath) ? file_get_contents($megaMenuOptionsPath) : '{}';
            $menu_template = ob_get_clean();
            echo Theme_NavMenu::getMenuHtml(array(
                'container_class' => 'u-align-left u-menu u-menu-dropdown u-offcanvas u-menu-1',
                'menu' => array(
                    'is_mega_menu' => false,
                    'menu_class' => 'u-nav u-unstyled u-nav-1',
                    'item_class' => 'u-nav-item',
                    'link_class' => 'u-button-style u-nav-link u-text-active-white u-text-hover-palette-1-light-2 u-text-white',
                    'link_style' => 'padding: 10px;',
                    'submenu_class' => 'u-h-spacing-20 u-nav u-unstyled u-v-spacing-10 u-block-a61e-34',
                    'submenu_item_class' => 'u-nav-item',
                    'submenu_link_class' => 'u-button-style u-nav-link u-white',
                    'submenu_link_style' => '',
                ),
                'responsive_menu' => array(
                    'is_mega_menu' => false,
                    'menu_class' => 'u-align-center u-nav u-popupmenu-items u-unstyled u-nav-2',
                    'item_class' => 'u-nav-item',
                    'link_class' => 'u-button-style u-nav-link',
                    'link_style' => 'padding: 10px;',
                    'submenu_class' => 'u-h-spacing-20 u-nav u-unstyled u-v-spacing-10 u-block-a61e-35',
                    'submenu_item_class' => 'u-nav-item',
                    'submenu_link_class' => 'u-button-style u-nav-link',
                    'submenu_link_style' => '',
                ),
                'theme_location' => 'primary-navigation-1',
                'template' => $menu_template,
                'mega_menu' => $megaMenu,
            )); ?>
    <div class="u-hover-feature u-social-icons u-spacing-10 u-social-icons-1">
      <a class="u-social-url" title="Steam Page" href="https://store.steampowered.com/app/1649920/Coronation/"><span class="u-icon u-social-custom u-social-icon u-icon-1"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 250 250" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-37a8"></use></svg><svg class="u-svg-content" viewBox="0 0 250 250" id="svg-37a8"><desc></desc><defs><linearGradient id="linearGradient-1" x1="50%" x2="50%" y1="0%" y2="100%"><stop offset="0%" stop-color="#111D2E"></stop><stop offset="21.248%" stop-color="#051839"></stop><stop offset="40.695%" stop-color="#0A1B48"></stop><stop offset="58.11%" stop-color="#132E62"></stop><stop offset="73.76%" stop-color="#144B7E"></stop><stop offset="87.279%" stop-color="#136497"></stop><stop offset="100%" stop-color="#1387B8"></stop>
</linearGradient>
</defs><g fill="none" fill-rule="evenodd" id="steam_logo" stroke="none" stroke-width="1"><path d="M4.98388829,160.954936 C20.443609,212.467811 68.2663802,250 124.865736,250 C193.974221,250 250,194.034335 250,125 C250,55.9645923 193.974221,0 124.865736,0 C58.5488722,0 4.28571429,51.5332618 0,116.695279 C8.09785177,130.27897 11.2577873,138.680258 4.98506982,160.954936 L4.98388829,160.954936 Z" fill="url(#linearGradient-1)" id="BG"></path><path d="M118.897563,97.8643356 C118.897563,98.0712933 118.897563,98.2782509 118.908337,98.4725376 L88.192176,142.199728 C83.2164768,141.977988 78.2235382,142.833272 73.4891895,144.744462 C71.4021541,145.578628 69.4465686,146.602857 67.6116582,147.785472 L0.1638896,120.574768 C0.164417554,120.574768 -1.39680774,145.737014 5.10726509,164.489909 L52.789074,183.770757 C55.1831848,194.255907 62.522826,203.45285 73.3512749,207.877097 C91.0679103,215.131174 111.495429,206.863427 118.865239,189.493769 C120.783114,184.953372 121.677403,180.191235 121.548109,175.439657 L165.497604,144.659989 C165.853165,144.670549 166.219501,144.681108 166.575062,144.681108 C192.875802,144.681108 214.252561,123.668573 214.252561,97.8643356 C214.252561,72.0579865 192.875802,51.0644582 166.575062,51.0644582 C140.285096,51.0644582 118.897563,72.0579865 118.897563,97.8643356 Z M111.527753,186.473878 C105.823692,199.894446 90.0863464,206.261561 76.4069447,200.675817 C70.0962755,198.099405 65.331758,193.379504 62.5831636,187.751524 L78.1039404,194.055284 C88.192176,198.173319 99.7662256,193.485095 103.959691,183.601812 C108.166085,173.707971 103.394025,162.346419 93.3111771,158.228385 L77.2667559,151.713443 C83.4578273,149.411568 90.4957803,149.327095 97.0715041,152.009097 C103.701101,154.712217 108.844883,159.801685 111.570851,166.306068 C114.296819,172.81045 114.286044,179.990613 111.527753,186.473878 Z M166.575062,129.053695 C149.066376,129.053695 134.811612,115.062937 134.811612,97.8643356 C134.811612,80.6794612 149.066376,66.6844796 166.575062,66.6844796 C184.094523,66.6844796 198.349287,80.6794612 198.349287,97.8643356 C198.349287,115.062937 184.094523,129.053695 166.575062,129.053695 Z M142.774023,97.8168199 C142.774023,84.8788004 153.462403,74.385204 166.628935,74.385204 C179.806241,74.385204 190.494621,84.8788004 190.494621,97.8168199 C190.494621,110.755895 179.806241,121.239989 166.628935,121.239989 C153.462403,121.239989 142.774023,110.755895 142.774023,97.8168199 Z" fill="#F2F2F2" fill-rule="nonzero" id="Shape"></path>
</g></svg></span>
      </a>
      <a class="u-social-url" target="_blank" title="Itch Page" href="https://mbdot00.itch.io/coronation"><span class="u-file-icon u-icon u-social-custom u-social-icon u-icon-2"><img src="<?php echo get_template_directory_uri(); ?>/images/communityIcon_2689u8uyhkg111.png" alt=""></span>
      </a>
      <a class="u-social-url" title="Discord" target="_blank" href="https://discord.com/invite/Z6XsSkpSNJ"><span class="u-icon u-social-facebook u-social-icon u-icon-3"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-b207"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" id="svg-b207"><circle cx="256" cy="256" fill="currentColor" id="ellipse" r="256"></circle><path d="M372.4,168.7c0,0-33.3-26.1-72.7-29.1l-3.5,7.1c35.6,8.7,51.9,21.2,69,36.5  c-29.4-15-58.5-29.1-109.1-29.1s-79.7,14.1-109.1,29.1c17.1-15.3,36.5-29.2,69-36.5l-3.5-7.1c-41.3,3.9-72.7,29.1-72.7,29.1  s-37.2,54-43.6,160c37.5,43.3,94.5,43.6,94.5,43.6l11.9-15.9c-20.2-7-43.1-19.6-62.8-42.3c23.5,17.8,59.1,36.4,116.4,36.4  s92.8-18.5,116.4-36.4c-19.7,22.7-42.6,35.3-62.8,42.3l11.9,15.9c0,0,57-0.3,94.5-43.6C409.6,222.7,372.4,168.7,372.4,168.7z   M208.7,299.6c-14.1,0-25.5-13-25.5-29.1s11.4-29.1,25.5-29.1c14.1,0,25.5,13,25.5,29.1S222.8,299.6,208.7,299.6z M303.3,299.6  c-14.1,0-25.5-13-25.5-29.1s11.4-29.1,25.5-29.1s25.5,13,25.5,29.1S317.3,299.6,303.3,299.6z" fill="#FFFFFF" id="logo"></path></svg></span>
      </a>
      <a class="u-social-url" target="_blank" title="Patreon" href="https://www.patreon.com/twinswordstudio"><span class="u-file-icon u-icon u-social-custom u-social-icon u-icon-4"><img src="<?php echo get_template_directory_uri(); ?>/images/patreon-2296036-19119951.png" alt=""></span>
      </a>
      <a class="u-social-url" title="Twitter" target="_blank" href="https://twitter.com/CoronationGame"><span class="u-icon u-social-icon u-social-twitter u-icon-5"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 1000 1000" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-0ab3"></use></svg><svg class="u-svg-content" viewBox="0 0 1000 1000" id="svg-0ab3" style="enable-background:new 0 0 1000 1000;"><style type="text/css"> .st0{fill:#1DA1F2;}
	.st1{fill:#FFFFFF;}
	.st2{fill:none;} </style><g><g id="Dark_Blue"><path class="st0" d="M500,0L500,0c276.1,0,500,223.9,500,500v0c0,276.1-223.9,500-500,500h0C223.9,1000,0,776.1,0,500v0    C0,223.9,223.9,0,500,0z"></path>
</g><g id="Logo_FIXED"><path class="st1" d="M384,754c235.8,0,364.9-195.4,364.9-364.9c0-5.5,0-11.1-0.4-16.6c25.1-18.2,46.8-40.6,64-66.4    c-23.4,10.4-48.2,17.2-73.6,20.2c26.8-16,46.8-41.2,56.4-70.9c-25.2,14.9-52.7,25.5-81.4,31.1c-48.6-51.6-129.8-54.1-181.4-5.6    c-33.3,31.3-47.4,78-37.1,122.5c-103.1-5.2-199.2-53.9-264.3-134c-34,58.6-16.7,133.5,39.7,171.2c-20.4-0.6-40.4-6.1-58.2-16    c0,0.5,0,1.1,0,1.6c0,61,43,113.6,102.9,125.7c-18.9,5.1-38.7,5.9-57.9,2.2c16.8,52.2,64.9,88,119.8,89.1    c-45.4,35.7-101.5,55.1-159.2,55c-10.2,0-20.4-0.6-30.5-1.9C246.1,734,314.4,754,384,753.9"></path><path class="st2" d="M500,0L500,0c276.1,0,500,223.9,500,500v0c0,276.1-223.9,500-500,500h0C223.9,1000,0,776.1,0,500v0    C0,223.9,223.9,0,500,0z"></path>
</g>
</g></svg></span>
      </a>
      <a class="u-social-url" title="Reddit" target="_blank" href="https://www.reddit.com/r/CoronationGame/"><span class="u-icon u-social-icon u-social-instagram u-icon-6"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 512 512" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-6970"></use></svg><svg class="u-svg-content" viewBox="0 0 512 512" id="svg-6970" style="fill-rule:evenodd;clip-rule:evenodd;stroke-linejoin:round;stroke-miterlimit:2;"><g id="Artwork"><circle cx="255.999" cy="255.999" r="256" style="fill:currentColor;"></circle><path d="M426.666,255.999c0,-20.659 -16.767,-37.427 -37.427,-37.427c-10.18,0 -19.163,3.893 -25.75,10.48c-25.45,-18.264 -60.781,-30.241 -99.705,-31.738l17.067,-79.944l55.391,11.677c0.599,14.073 12.276,25.451 26.648,25.451c14.672,0 26.648,-11.977 26.648,-26.648c0,-14.672 -11.976,-26.648 -26.648,-26.648c-10.479,0 -19.462,5.988 -23.653,14.97l-61.979,-13.174c-1.797,-0.299 -3.593,0 -5.09,0.898c-1.497,0.899 -2.396,2.396 -2.995,4.192l-18.863,89.226c-39.822,1.198 -75.452,12.875 -101.202,31.738c-6.587,-6.288 -15.869,-10.48 -25.75,-10.48c-20.659,0 -37.426,16.768 -37.426,37.427c0,15.27 8.982,28.145 22.156,34.134c-0.599,3.593 -0.898,7.485 -0.898,11.377c0,57.488 66.77,103.897 149.408,103.897c82.639,0 149.408,-46.409 149.408,-103.897c0,-3.892 -0.299,-7.485 -0.898,-11.078c12.276,-5.988 21.558,-19.163 21.558,-34.433Zm-256,26.648c0,-14.671 11.977,-26.648 26.648,-26.648c14.671,0 26.648,11.977 26.648,26.648c0,14.672 -11.977,26.648 -26.648,26.648c-14.671,0 -26.648,-11.976 -26.648,-26.648Zm148.809,70.363c-18.264,18.264 -52.996,19.462 -63.176,19.462c-10.18,0 -45.212,-1.497 -63.177,-19.462c-2.695,-2.695 -2.695,-7.186 0,-9.881c2.695,-2.695 7.186,-2.695 9.881,0c11.378,11.378 35.93,15.57 53.595,15.57c17.666,0 41.918,-4.192 53.595,-15.57c2.695,-2.695 7.186,-2.695 9.881,0c2.096,2.994 2.096,7.186 -0.599,9.881Zm-4.79,-43.715c-14.672,0 -26.648,-11.976 -26.648,-26.648c0,-14.671 11.976,-26.648 26.648,-26.648c14.671,0 26.648,11.977 26.648,26.648c0,14.672 -11.977,26.648 -26.648,26.648Z" style="fill:#fff;fill-rule:nonzero;"></path>
</g></svg></span>
      </a>
      <a class="u-social-url" target="_blank" title="YouTube" href="https://www.youtube.com/channel/UCmptOCj60LYP1DXf0R3C1yQ"><span class="u-icon u-social-icon u-social-youtube u-icon-7"><svg class="u-svg-link" preserveAspectRatio="xMidYMin slice" viewBox="0 0 112 112" style=""><use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#svg-4129"></use></svg><svg class="u-svg-content" viewBox="0 0 112 112" x="0" y="0" id="svg-4129"><circle fill="currentColor" cx="56.1" cy="56.1" r="55"></circle><path fill="#FFFFFF" d="M74.9,33.3H37.3c-7.4,0-13.4,6-13.4,13.4v18.8c0,7.4,6,13.4,13.4,13.4h37.6c7.4,0,13.4-6,13.4-13.4V46.7 C88.3,39.3,82.3,33.3,74.9,33.3L74.9,33.3z M65.9,57l-17.6,8.4c-0.5,0.2-1-0.1-1-0.6V47.5c0-0.5,0.6-0.9,1-0.6l17.6,8.9 C66.4,56,66.4,56.8,65.9,57L65.9,57z"></path></svg></span>
      </a>
    </div>
  </div>
</header>