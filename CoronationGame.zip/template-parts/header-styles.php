<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Roboto+Slab:100,200,300,400,500,600,700,800,900">
<style> .u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 63px;
}
.u-header .u-menu-1 {
  margin: 14px auto 0 0;
}
.u-header .u-nav-1 {
  font-size: 0.875rem;
  font-weight: normal;
}
.u-block-a61e-34 {
  font-size: 1rem;
}
.u-header .u-nav-2 {
  font-size: 1rem;
}
.u-block-a61e-35 {
  font-size: 1rem;
}
.u-header .u-social-icons-1 {
  white-space: nowrap;
  height: 26px;
  min-height: 16px;
  width: 242px;
  min-width: 172px;
  transition-duration: 0.5s;
  margin: -29px 0 19px auto;
}
.u-header .u-icon-1 {
  height: 100%;
  color: rgb(255, 255, 255) !important;
}
.u-header .u-icon-2 {
  height: 0;
}
.u-header .u-icon-3 {
  color: rgb(140, 158, 255) !important;
}
.u-header .u-icon-4 {
  height: 0;
}
.u-header .u-icon-5 {
  color: rgb(255, 255, 255) !important;
}
.u-header .u-icon-6 {
  color: rgb(255, 69, 0) !important;
}
.u-header .u-icon-7 {
  height: 100%;
  color: rgb(210, 34, 21) !important;
}
@media (max-width: 991px) {
  .u-header .u-sheet-1 {
    min-height: 90px;
  }
  .u-header .u-social-icons-1 {
    margin-top: -12px;
    margin-bottom: 32px;
  }
}
@media (max-width: 767px) {
  .u-header .u-menu-1 {
    width: auto;
    margin-top: 30px;
  }
  .u-header .u-social-icons-1 {
    margin-top: -28px;
    margin-right: -29px;
    margin-bottom: 32px;
  }
}
.u-header .u-social-icons-1 {
  transition-property: fill, color, background-image, stroke-width, border-style, border-width, box-shadow, text-shadow, opacity, border-radius, stroke, border-color, font-size, font-style, font-weight, text-decoration, letter-spacing, transform, background-size, background-position !important;
}
.u-header .u-social-icons-1:hover {
  transform: translateX(0px) translateY(-2px) scale(1) !important;
}</style>
